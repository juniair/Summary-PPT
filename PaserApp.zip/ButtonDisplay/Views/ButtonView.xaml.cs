﻿using System.Windows.Controls;

namespace ButtonDisplay.Views
{
    /// <summary>
    /// Interaction logic for ButtonView
    /// </summary>
    public partial class ButtonView : UserControl
    {
        public ButtonView()
        {
            InitializeComponent();
        }
    }
}
