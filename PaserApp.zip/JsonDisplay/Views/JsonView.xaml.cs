﻿using System.Windows.Controls;

namespace JsonDisplay.Views
{
    /// <summary>
    /// Interaction logic for JsonView
    /// </summary>
    public partial class JsonView : UserControl
    {
        public JsonView()
        {
            InitializeComponent();
        }
    }
}
