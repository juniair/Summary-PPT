﻿using ModuleA.Views;
using Prism.Modularity;
using Prism.Regions;
using System;

namespace ModuleA
{
    public class ModuleAModule : IModule
    {
        IRegionManager _regionManager;

        public ModuleAModule(IRegionManager regionManager)
        {

            _regionManager = regionManager;
        }

        public void Initialize()
        {


            _regionManager.RegisterViewWithRegion("ContentRegion", typeof(ContentView));
        }
    }
}