﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleClickOnceApp.Infrastructure
{
    public class RegionName
    {
        public static string ToolbarRegion = "ToolbarRegion";
        public static string ContentRegion = "ContentRegion";
    }
}
