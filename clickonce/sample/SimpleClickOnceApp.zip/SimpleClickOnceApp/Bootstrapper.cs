﻿using Microsoft.Practices.Unity;
using ModuleA;
using Prism.Modularity;
using Prism.Regions;
using Prism.Unity;
using SimpleClickOnceApp.Views;
using System.Windows;
using System.Windows.Controls;

namespace SimpleClickOnceApp
{
    class Bootstrapper : UnityBootstrapper
    {
        protected override DependencyObject CreateShell()
        {
            return Container.Resolve<MainWindow>();
        }

        protected override void InitializeShell()
        {
            base.InitializeShell();

            App.Current.MainWindow = (Window)Shell;
            App.Current.MainWindow.Show();
        }

        protected override IModuleCatalog CreateModuleCatalog()
        {
            ModuleCatalog catalog = new ModuleCatalog();
            catalog.AddModule(typeof(ModuleAModule));
            return catalog;
        }

    }
}
